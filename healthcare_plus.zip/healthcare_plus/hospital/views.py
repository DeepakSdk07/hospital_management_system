from django.shortcuts import render,redirect
from .forms import PatientForm,AppointmentForm
from .models import Doctor,Appointment

def home(request):
    return render(request,'hospital/home.html')

def add_patient(request):
    form=PatientForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('home')
    return render(request,'hospital/add_patient.html',{'form':form})

def book_appointment(request):
    form=AppointmentForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('home')
    return render(request,'hospital/book_appointment.html',{'form':form})

def appointment_list(request):
    appoinments=Appointment.objects.all()
    return render(request,'appointment_list.html',{'appointments':appoinments})
