from django.urls import path
from . import views
from .views import home,add_patient,book_appointment,appointment_list

urlpatterns=[
    path('',views.home,name='home'),
    path('add-patient/',add_patient,name='add_patient'),
    path('book-appointment/',book_appointment,name='book_appoinment'),
    path('appoinment-list/',appointment_list,name='appoinment_list'),
]